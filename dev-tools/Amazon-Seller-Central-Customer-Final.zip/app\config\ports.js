module.exports = {
  backend: 3001,
  frontend: 3000,
  admin: 3002
};