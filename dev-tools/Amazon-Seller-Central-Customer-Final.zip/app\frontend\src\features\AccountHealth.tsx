
import React, { useState, useEffect } from 'react';
import { ShieldCheck, ChevronRight, ChevronDown, ChevronUp } from 'lucide-react';
import { useI18n } from '../hooks/useI18n';
import { useStore } from '../store';
import { apiGet } from '../config/api';

interface AccountHealthData {
  id: string;
  store_id: string;
  order_defect_rate: {
    seller_fulfilled: number;
    fulfilled_by_amazon: number;
  };
  policy_violations: {
    negative_feedback: number;
    a_to_z_claims: number;
    chargeback_claims: number;
  };
  account_health_rating: number;
  shipping_performance: {
    late_shipment_rate: number;
    pre_fulfillment_cancel_rate: number;
    valid_tracking_rate: number;
    on_time_delivery_rate: number | null;
  };
  policy_compliance: {
    product_policy_violations: number;
    listing_policy_violations: number;
    intellectual_property_violations: number;
    customer_product_reviews: number;
    other_policy_violations: number;
  };
  updated_at: string;
}

const AccountHealth: React.FC = () => {
  const { t } = useI18n();
  const { currentStore } = useStore();
  const [accountHealthData, setAccountHealthData] = useState<AccountHealthData | null>(null);
  const [loading, setLoading] = useState(false);
  const [allIssuesExpanded, setAllIssuesExpanded] = useState(true);

  // Load account health data from backend
  useEffect(() => {
    const loadAccountHealthData = async () => {
      if (!currentStore?.id) return;

      try {
        setLoading(true);
        const response = await apiGet(`/api/account-health/${currentStore.id}`);
        if (response.success && response.data) {
          setAccountHealthData(response.data);
        }
      } catch (error) {
        console.error('Failed to load account health data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadAccountHealthData();
  }, [currentStore]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="w-12 h-12 border-4 border-amazon-teal border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="bg-[#f3f3f3] min-h-screen">
      {/* Page Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-[1200px] mx-auto">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-xl font-normal text-[#0F1111] mb-2">Account Health</h1>
              <p className="text-sm text-[#565959] leading-relaxed max-w-2xl">
                To set up Amazon's trust advisor to be better performance targets and policies.
                <br />
                Report abuse of Amazon policies that affects your ability to sell by entering your
                emergency contact number <a href="#" className="text-[#007185] hover:underline">here</a>.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button className="bg-[#00A652] text-white px-4 py-2 text-sm font-medium rounded hover:bg-[#008A42] transition-colors">
                Need help?
              </button>
              <button className="bg-[#FFD814] text-[#0F1111] px-4 py-2 text-sm font-medium rounded hover:bg-[#F7CA00] transition-colors">
                Contact Us
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-[1200px] mx-auto px-6 py-6">
        {/* Three Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Customer Service Performance */}
          <div className="bg-white rounded border border-gray-200 p-6">
            <h2 className="text-lg font-medium text-[#0F1111] mb-6">Customer Service Performance</h2>
            
            {/* Order Defect Rate */}
            <div className="mb-6">
              <h3 className="text-sm font-medium text-[#0F1111] mb-2">Order Defect Rate</h3>
              <p className="text-xs text-[#565959] mb-4">Target: under 1%</p>
              
              {/* Two Column Data */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="text-center">
                  <p className="text-xs text-[#565959] mb-1">Seller Fulfilled</p>
                  <p className="text-2xl font-normal text-[#0F1111]">2%</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-[#565959] mb-1">Fulfilled by Amazon</p>
                  <p className="text-2xl font-normal text-[#0F1111]">6%</p>
                </div>
              </div>
              
              <p className="text-xs text-[#565959] mb-3">
                Order Defect Rate consists of three different metrics:
              </p>
              
              {/* Metrics Breakdown */}
              <div className="space-y-2 mb-4">
                <div className="flex justify-between text-xs">
                  <span className="text-[#565959]">• Negative Feedback</span>
                  <span className="text-[#0F1111]">1% vs 6%</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-[#565959]">• A-to-Z Guarantee claims</span>
                  <span className="text-[#0F1111]">5% vs 8%</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-[#565959]">• Chargeback claims</span>
                  <span className="text-[#0F1111]">9% vs 7%</span>
                </div>
              </div>
              
              <a href="#" className="text-[#007185] text-sm hover:underline">View details</a>
            </div>
          </div>

          {/* Policy Compliance */}
          <div className="bg-white rounded border border-gray-200 p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-medium text-[#0F1111]">Policy Compliance</h2>
              <span className="bg-[#D5EDDA] text-[#155724] px-3 py-1 rounded-full text-xs font-medium">
                Healthy
              </span>
            </div>
            
            {/* Account Health Rating */}
            <div className="mb-6">
              <h3 className="text-sm font-medium text-[#0F1111] mb-2">Account Health Rating</h3>
              <p className="text-3xl font-normal text-[#0F1111] mb-4">946</p>
              
              {/* Progress Bar */}
              <div className="relative mb-2">
                <div className="w-full h-3 bg-gray-200 rounded-sm">
                  <div 
                    className="h-3 bg-[#00A652] rounded-sm" 
                    style={{ width: '94.6%' }}
                  ></div>
                </div>
              </div>
              <div className="flex justify-between text-xs text-[#565959]">
                <span>0</span>
                <span>100</span>
                <span>200</span>
                <span>1000</span>
              </div>
            </div>
            
            {/* All Issues */}
            <div>
              <div 
                className="flex justify-between items-center cursor-pointer mb-3"
                onClick={() => setAllIssuesExpanded(!allIssuesExpanded)}
              >
                <h3 className="text-sm font-medium text-[#0F1111]">All Issues</h3>
                {allIssuesExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
              </div>
              
              {allIssuesExpanded && (
                <div className="space-y-3 mb-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[#007185] hover:underline cursor-pointer">
                      Suspected Intellectual Property Violations
                    </span>
                    <span className="text-lg font-normal text-[#0F1111]">0</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[#007185] hover:underline cursor-pointer">
                      Received Intellectual Property Complaints
                    </span>
                    <span className="text-lg font-normal text-[#0F1111]">0</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[#007185] hover:underline cursor-pointer">
                      Product Authenticity Customer Complaints
                    </span>
                    <span className="text-lg font-normal text-[#0F1111]">0</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[#007185] hover:underline cursor-pointer">
                      Product Condition Customer Complaints
                    </span>
                    <span className="text-lg font-normal text-[#0F1111]">0</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[#007185] hover:underline cursor-pointer">
                      Food and Product Safety Issues
                    </span>
                    <span className="text-lg font-normal text-[#0F1111]">0</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[#007185] hover:underline cursor-pointer">
                      Listing Policy Violations
                    </span>
                    <span className="text-lg font-normal text-[#0F1111]">0</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[#007185] hover:underline cursor-pointer">
                      Restricted Product Policy Violations
                    </span>
                    <span className="text-lg font-normal text-[#0F1111]">0</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[#007185] hover:underline cursor-pointer">
                      Customer Product Reviews Policy Violations
                    </span>
                    <span className="text-lg font-normal text-[#0F1111]">0</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[#007185] hover:underline cursor-pointer">
                      Other Policy Violations
                    </span>
                    <span className="text-lg font-normal text-[#0F1111]">0</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[#007185] hover:underline cursor-pointer">
                      Regulatory Compliance
                    </span>
                    <span className="text-lg font-normal text-[#0F1111]">0</span>
                  </div>
                </div>
              )}
              
              <a href="#" className="text-[#007185] text-sm hover:underline">View all (0)</a>
            </div>
          </div>

          {/* Shipping Performance */}
          <div className="bg-white rounded border border-gray-200 p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-medium text-[#0F1111]">Shipping Performance</h2>
              <div className="flex items-center gap-1 text-[#007185] text-sm cursor-pointer hover:underline">
                <span>Seller fulfilled</span>
                <ChevronDown size={14} />
              </div>
            </div>
            
            {/* Shipping Metrics */}
            <div className="space-y-6">
              <div>
                <div className="flex justify-between items-start mb-1">
                  <div>
                    <p className="text-sm font-medium text-[#0F1111]">Late Shipment Rate</p>
                    <p className="text-xs text-[#565959]">Target: under 4%, 30 days</p>
                  </div>
                  <p className="text-lg font-normal text-[#0F1111]">3%</p>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-start mb-1">
                  <div>
                    <p className="text-sm font-medium text-[#0F1111]">Pre-fulfillment Cancel Rate</p>
                    <p className="text-xs text-[#565959]">Target: under 2.5%, 7 days</p>
                  </div>
                  <p className="text-lg font-normal text-[#0F1111]">6%</p>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-start mb-1">
                  <div>
                    <p className="text-sm font-medium text-[#0F1111]">Valid Tracking Rate</p>
                    <p className="text-xs text-[#565959]">Target: over 95%, 30 days</p>
                  </div>
                  <p className="text-lg font-normal text-[#0F1111]">92%</p>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-start mb-1">
                  <div>
                    <p className="text-sm font-medium text-[#0F1111]">On-Time Delivery Rate</p>
                    <p className="text-xs text-[#565959]">Target: over 90%</p>
                  </div>
                  <p className="text-lg font-normal text-[#0F1111]">93%</p>
                </div>
              </div>
            </div>
            
            {/* Bottom Links */}
            <div className="mt-6 pt-4 border-t border-gray-200 space-y-2">
              <a href="#" className="text-[#007185] text-sm hover:underline block">View Details</a>
              <a href="#" className="text-[#007185] text-sm hover:underline block">View shipping eligibilities here</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountHealth;
